Source Version: 2.6.32 released 2008.04.08

Source From: http://www.xmlsoft.org/

In project: libxml2 in static, static for dll and dll versions

All binaries have .rc files for version info specifying which compiler used and that these are 'special builds'

configure is normal, makefile was patched to add .rc information and to dump debug symbols for release builds