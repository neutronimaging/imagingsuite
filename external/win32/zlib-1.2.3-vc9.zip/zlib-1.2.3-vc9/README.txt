Source Version: 1.2.3 2005.06.18 release

Source From: http://www.zlib.net/

In project: zlib in static library and dll versions

All binaries have .rc files for version info specifying which compiler used and that these are 'special builds'

No source files were modified - the ZLIB_DLL was used to export symbols
these builds are standard and do not have ASM support